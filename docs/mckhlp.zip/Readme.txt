Mirror Classes Kit for Key Objects Library HELP.
Version 1.0.94 (1-Sep-2001), for KOL/MCK v0.94
Copyright (C) By Vladimir Kladov, 2001
------------------------------------------------
http://kol.thaddy.co.uk
mailto: bonanzas@xcl.cjb.net
------------------------------------------------

This help file can be integrated to your Delphi help system, so F1 and Ctrl+F1 keyboard key combinations become available to get help about MCK/KOL components, objects, etc.

INSTALLATION

1. Unpack all files to directory, there Delphi help files are located (for Delphi5, this is \Help subdirectory of Delphi installation directory).
2. Run oh.exe utility from \Bin subdirectory of Delphi installation.
3. Open existing help project.
4. Add MCK.toc file there.
5. Save this project (may be under another name, this does not care). All changes will be applied, and this MCK/KOL help will be fully integrated into your Delphi help system.
(It is not necessary to close another applications, and even to stop Delphi from running).
Enjoy!

